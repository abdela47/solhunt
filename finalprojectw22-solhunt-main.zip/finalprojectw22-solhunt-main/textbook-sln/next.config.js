module.exports = {
	reactStrictMode: true,
};
