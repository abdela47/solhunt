export const navConfig = [
	{ link: '/login', name: 'login' },
	{ link: '/sign_up', name: 'sign up' },
];

