US to add:
- Valid ISBN checker
- Login/Sign up on the home page
- Make each pages work properly with authenticated users i.e if you're logged: when you comment it should appear as the logged in user commenting you cannot comment/like if you're not logged in if you're logged in you can like ONCE your user profile should show yo
- Some sort of navbar so we can navigate to user profile, and has a search bar
- Join solutions and comments page
- Proper solution page (Can actually add a solution)
- Mods can view requests and delete them
- Mods can view and delete flagged solutions comments
- connect Auth and DB
- Changing pages based on if the user is a mod or not

Incomplete US:
- SOL-3
- SOL-49
- SOL-19
- SOL-17
- SOL-14
- SOL-15
- SOL-9
- SOL-50
- SOL-74
- SOL-75
- SOL-53
- SOL-54
- SOL-6


New Practices:
- After you add a function please document it - look into options for documentation
    
Practices to Continue:
- Regular meetings
- Asking for help when needed
- Regular chat updates

Bad Practices:
- last minute documentation
- last minute docs

Worst Experience:
- Doing the docs last minute

Participants:
- All Team Members

