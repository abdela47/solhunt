US to add:
- As a moderator, only I should be able to see and access the moderator page to prevent missuse
- As a user, I want to have a unique username that can be traced back to my account.
- As a user, I want my information (such as name, email, username) to show on my home page

Incomplete US:
- SOL-3
- SOL-9
- SOL-14
- SOL-15
- SOL-17
- SOL-19
- SOL-53
- SOL-54
- SOL-75
- SOL-82
- SOL-83
- SOL-85
- SOL-84
- SOL-86
- SOL-91

New Practices:
- Ask for help quickly if stuck
    
Practices to Continue:
- Regular meetings
- Asking for help when needed
- Regular chat updates

Bad Practices:
- last minute documentation
- last minute docs

Worst Experience:
- Being embarassed to ask for help

Participants:
- All Team Members

