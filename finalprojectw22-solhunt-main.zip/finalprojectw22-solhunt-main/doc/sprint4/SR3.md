US to add:
- As a user, I want to post solutions and comments with my own username so my contributions can be attributed to me
- As a moderator, I want the ability to update existing textbooks, so that I may edit possible mistakes
- As a user, I should be able to only like/flag a comment/solution once, so that all users can express their opinions fairly

Incomplete US
- SOL-3
- SOL-9
- SOL-14
- SOL-17
- SOL-54
- SOL-82
- SOL-91

New Practices:
- Break large US into small tasks sooner rather than later
    
Practices to Continue:
- Regular meetings
- Asking for help when needed
- Regular chat updates

Bad Practices:
- Breaking big US's down late 

Worst Experience:
- Dealing with bug in SOL-9

Participants:
- All Team Members

