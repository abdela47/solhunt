| Full Name | UTORID | Student ID | Email | Best Way to Contact |Discord Username | 
|-----------|--------|------------|-------|---------------------|------------------|
|Yousef Akiba|akibayou|1005041152|yousef.akiba@mail.utoronto.ca||AKIBABA#1344| 
|Thivagar Nadarajan|sandras4|1003606127|thiv.nadarajan@mail.utoronto.ca|thiv.nadarajan@gmail.com|thivster#8862| 
|Thiago Vidal Murakami|muraka21|1006125060|thiago.murakami@mail.utoronto.ca||thimura#1410|
|Ahmed Abdelaziz|abdela47|1006390175|ahmedymt.abdelaziz@mail.utoronto.ca|ahmed.ym.tawfik@hotmail.com|Ahmed.Tawfik#0281|
|Thomas Verdier|verdiert|1005217775|thomas.verdier@mail.utoronto.ca|thoverdier@outlook.com|tho10#9176|
|Ali Abushaban|abushab6|1006244645|ali.abushaban@mail.utoronto.ca|alia-10-2001@hotmail.com|ali.12#3679|
