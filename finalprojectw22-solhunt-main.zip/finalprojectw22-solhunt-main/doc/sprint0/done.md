We consider the project to be done if:
- A user can successfully add/view solutions to a textbook
- A user can use latex in their solutions if needed 
- A user can comment/upvote the solutions of others
- A user can flag/downvote solutions,comments
- A user can see the contributions they've made to the site and the contributions of others
- A user can easily sign up for the site
- A user doesn't incur any more difficulty using the site on mobile compared to on desktop

- A moderator for the website can easily moderate the site by:
 - Removing problematic comments/solutions
 - Add/remove textbooks 


