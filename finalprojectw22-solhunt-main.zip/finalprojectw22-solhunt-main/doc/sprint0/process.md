TEAM ORGANZIATION:

Thivagar and Yousef worked on the setup and PB.md

Yousef worked on done.md

Thivagar worked on personas.pdf 

Thomas worked on the team_contract.pdf and summary.md

Thiago worked on the UX and competition.md

Ahmed worked on readme.md

For next sprint team members will work in specfic categories i.e: Backend or Frontend

DECISION MAKING: 

On issues where there isn't a clear answer and the team is unable to agree team members vote on potential solutions

PRIORITIZING USER STORIES:

User stories relating to functionality of the site are prioritized over user stories relating 
to the look of the site. 

MEETINGS:

For new features that are implemented, the implementer of the feature and the chosen reviewers will schedule 
a meeting to discuss the feature 

Between 1-2 times a week meetings will be scheduled for all team members to discuss project progress and identiy 
areas of improvement

NEXT PHASE: 

We will select user stories with a strong preference for user stories relating to functionality and begin working on them 

Since we are following MVC we will also start creating the classes for our model

